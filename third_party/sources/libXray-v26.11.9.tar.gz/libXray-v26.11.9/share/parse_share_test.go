package share

import (
	"encoding/base64"
	"encoding/json"
	"net/url"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/xtls/xray-core/infra/conf"
)

const testShareUUID = "12345678-abcd-abcd-abcd-123456789abc"

func ssUserB64(cipher, password string) string {
	return base64.StdEncoding.EncodeToString([]byte(cipher + ":" + password))
}

func TestFixWindowsReturn(t *testing.T) {
	in := "a\r\nb\r\nc"
	assert.Equal(t, "a\nb\nc", FixWindowsReturn(in))
}

func TestConvertShareLinksToXrayJson_XrayJSONRoundTrip(t *testing.T) {
	orig, err := convertShareLinksForTest(
		"vless://" + testShareUUID + "@example.com:443?encryption=none&security=tls&sni=example.com&type=ws&path=%2Fp&host=cdn.example.com#tag1",
	)
	require.NoError(t, err)
	require.Len(t, orig.OutboundConfigs, 1)

	raw, err := json.Marshal(orig)
	require.NoError(t, err)

	again, err := convertShareLinksForTest(string(raw))
	require.NoError(t, err)
	require.Len(t, again.OutboundConfigs, 1)
	assert.Equal(t, orig.OutboundConfigs[0].Protocol, again.OutboundConfigs[0].Protocol)
}

func TestConvertShareLinksToXrayJson_XrayJSONKeepsOnlyOutbounds(t *testing.T) {
	config, err := convertShareLinksForTest(`{
		"env": {"TEST_ENV": "value"},
		"log": {"loglevel": "debug"},
		"routing": {"rules": []},
		"dns": {"servers": ["8.8.8.8"]},
		"inbounds": [{"protocol": "http", "listen": "127.0.0.1", "port": 1080, "settings": {}}],
		"outbounds": [{"protocol": "freedom", "tag": "direct", "settings": {}}],
		"policy": {"levels": {}},
		"metrics": {"tag": "metrics"},
		"stats": {},
		"fakeDns": {"ipPool": "198.18.0.0/15", "poolSize": 65535}
	}`)
	require.NoError(t, err)
	require.Len(t, config.OutboundConfigs, 1)
	assert.Equal(t, "direct", config.OutboundConfigs[0].Tag)
	assert.Equal(t, &conf.Config{OutboundConfigs: config.OutboundConfigs}, config)
}

func TestConvertShareLinksToXrayJson_XrayJSONInvalid(t *testing.T) {
	_, err := convertShareLinksForTest("{not json")
	require.Error(t, err)
}

func TestConvertShareLinksToXrayJson_XrayJSONNoOutbounds(t *testing.T) {
	_, err := convertShareLinksForTest(`{"outbounds":[]}`)
	require.Error(t, err)
	assert.Contains(t, err.Error(), "outbound")
}

func TestConvertShareLinksToXrayJson_FiltersBuildInvalidOutbounds(t *testing.T) {
	links := "vless://2418d087-648k-4990-86e8-19dca1d006d3@invalid-id.example:443?encryption=none&security=tls&sni=invalid-id.example&fp=chrome\n" +
		"vless://" + testShareUUID + "@invalid-reality.example:443?encryption=none&security=reality&sni=invalid-reality.example&pbk=invalid&fp=chrome\n" +
		"vless://" + testShareUUID + "@valid.example:443?encryption=none&security=tls&sni=valid.example&fp=chrome#Valid"

	config, err := convertShareLinksForTest(links)
	require.NoError(t, err)
	require.Len(t, config.OutboundConfigs, 1)
	assert.Equal(t, "Valid", config.OutboundConfigs[0].Tag)
	assert.Nil(t, config.OutboundConfigs[0].SendThrough)
}

func TestConvertShareLinksToXrayJson_AllBuildInvalidOutbounds(t *testing.T) {
	_, err := convertShareLinksForTest(
		"vless://2418d087-648k-4990-86e8-19dca1d006d3@invalid.example:443?encryption=none&security=tls&sni=invalid.example&fp=chrome",
	)

	require.Error(t, err)
	assert.EqualError(t, err, "no valid outbound found")
}

func TestConvertShareLinksToXrayJson_Base64EncodedLines(t *testing.T) {
	lines := "trojan://secret@trojan.example.com:443?sni=trojan.example.com\n" +
		"ss://" + ssUserB64("aes-128-gcm", "pwd") + "@ss.example.com:8388#ssn\n" +
		"vmess://" + testShareUUID + "@vm.example:443?encryption=auto&type=ws#VMessAEAD"
	blob := base64.StdEncoding.EncodeToString([]byte(lines))

	cfg, err := convertShareLinksForTest(blob)
	require.NoError(t, err)
	require.Len(t, cfg.OutboundConfigs, 3)
	assert.Equal(t, "trojan", cfg.OutboundConfigs[0].Protocol)
	assert.Equal(t, "shadowsocks", cfg.OutboundConfigs[1].Protocol)
	assert.Equal(t, "vmess", cfg.OutboundConfigs[2].Protocol)
}

func TestConvertShareLinksToXrayJson_Base64URLSafeBlob(t *testing.T) {
	inner := "vless://" + testShareUUID + "@10.0.0.1:443?encryption=none&security=none"
	b := base64.URLEncoding.WithPadding(base64.NoPadding).EncodeToString([]byte(inner))
	cfg, err := convertShareLinksForTest(b)
	require.NoError(t, err)
	require.Len(t, cfg.OutboundConfigs, 1)
	assert.Equal(t, "vless", cfg.OutboundConfigs[0].Protocol)
}

func TestConvertShareLinksToXrayJson_Shadowsocks(t *testing.T) {
	link := "ss://" + ssUserB64("chacha20-ietf-poly1305", "mypass") + "@10.0.0.1:8388#frag"
	cfg, err := convertShareLinksForTest(link)
	require.NoError(t, err)
	require.Len(t, cfg.OutboundConfigs, 1)
	ob := cfg.OutboundConfigs[0]
	assert.Equal(t, "shadowsocks", ob.Protocol)
	var s conf.ShadowsocksClientConfig
	require.NoError(t, json.Unmarshal(*ob.Settings, &s))
	assert.Equal(t, "chacha20-ietf-poly1305", s.Cipher)
	assert.Equal(t, "mypass", s.Password)
	assert.Equal(t, uint16(8388), s.Port)
}

func TestConvertShareLinksToXrayJson_ShadowsocksPlainUserInfo(t *testing.T) {
	const password = "YctPZ6U7xPPcU+gp3u+0tx/tRizJN9K8y+uKlW2qjlI="
	link := "ss://2022-blake3-aes-256-gcm:" +
		url.QueryEscape(password) +
		"@192.168.100.1:8888#Example3"

	cfg, err := convertShareLinksForTest(link)
	require.NoError(t, err)
	require.Len(t, cfg.OutboundConfigs, 1)

	ob := cfg.OutboundConfigs[0]
	assert.Equal(t, "shadowsocks", ob.Protocol)
	var settings conf.ShadowsocksClientConfig
	require.NoError(t, json.Unmarshal(*ob.Settings, &settings))
	assert.Equal(t, "2022-blake3-aes-256-gcm", settings.Cipher)
	assert.Equal(t, password, settings.Password)
	assert.Equal(t, uint16(8888), settings.Port)
}

func TestParseShadowsocksUserInfo_PlainPercentEncoding(t *testing.T) {
	link, err := url.Parse(
		"ss://aes-128-gcm:p%40ss%3Aword%2Fwith%2Bsymbols@ss.example.com:8388",
	)
	require.NoError(t, err)

	cipher, password, err := parseShadowsocksUserInfo(link.User)
	require.NoError(t, err)
	assert.Equal(t, "aes-128-gcm", cipher)
	assert.Equal(t, "p@ss:word/with+symbols", password)
}

func TestConvertShareLinksToXrayJson_VlessWSAndTLS(t *testing.T) {
	link := "vless://" + testShareUUID + "@edge.example:443?encryption=none&type=ws&path=%2Fws&host=cdn.edge&security=tls&sni=edge.example&alpn=h2%2Ch3&fp=chrome&vcn=edge.example"
	cfg, err := convertShareLinksForTest(link)
	require.NoError(t, err)
	require.Len(t, cfg.OutboundConfigs, 1)
	ss := cfg.OutboundConfigs[0].StreamSetting
	require.NotNil(t, ss)
	assert.Equal(t, "tls", ss.Security)
	require.NotNil(t, ss.WSSettings)
	assert.Equal(t, "/ws", ss.WSSettings.Path)
	assert.Equal(t, "cdn.edge", ss.WSSettings.Host)
	require.NotNil(t, ss.TLSSettings)
	assert.Equal(t, "edge.example", ss.TLSSettings.ServerName)
	assert.Equal(t, "chrome", ss.TLSSettings.Fingerprint)
	assert.Equal(t, "edge.example", ss.TLSSettings.VerifyPeerCertByName)
	require.NotNil(t, ss.TLSSettings.ALPN)
	assert.Contains(t, []string(*ss.TLSSettings.ALPN), "h2")
}

func TestConvertShareLinksToXrayJson_VlessReality(t *testing.T) {
	pbk := "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
	link := "vless://" + testShareUUID + "@reality.example:443?encryption=none&security=reality&type=tcp&sni=reality.example&pbk=" +
		pbk + "&sid=abcd&fp=chrome&spx=%2F"
	cfg, err := convertShareLinksForTest(link)
	require.NoError(t, err)
	ss := cfg.OutboundConfigs[0].StreamSetting
	require.NotNil(t, ss)
	assert.Equal(t, "reality", ss.Security)
	require.NotNil(t, ss.REALITYSettings)
	assert.Equal(t, pbk, ss.REALITYSettings.PublicKey)
	assert.Equal(t, "abcd", ss.REALITYSettings.ShortId)
	assert.Equal(t, "chrome", ss.REALITYSettings.Fingerprint)
	assert.Equal(t, "/", ss.REALITYSettings.SpiderX)
}

func TestConvertShareLinksToXrayJson_Trojan(t *testing.T) {
	link := "trojan://tpw@trojan.host:4443?sni=trojan.host#tname"
	cfg, err := convertShareLinksForTest(link)
	require.NoError(t, err)
	var s conf.TrojanClientConfig
	require.NoError(t, json.Unmarshal(*cfg.OutboundConfigs[0].Settings, &s))
	assert.Equal(t, "tpw", s.Password)
	assert.Equal(t, uint16(4443), s.Port)
	ss := cfg.OutboundConfigs[0].StreamSetting
	require.NotNil(t, ss)
	assert.Equal(t, "tls", ss.Security)
}

func TestConvertShareLinksToXrayJson_SocksWithAuth(t *testing.T) {
	u := base64.StdEncoding.EncodeToString([]byte("socksuser:sockspass"))
	link := "socks://" + u + "@127.0.0.1:1081#sk"
	cfg, err := convertShareLinksForTest(link)
	require.NoError(t, err)
	var s conf.SocksClientConfig
	require.NoError(t, json.Unmarshal(*cfg.OutboundConfigs[0].Settings, &s))
	assert.Equal(t, "socksuser", s.Username)
	assert.Equal(t, "sockspass", s.Password)
}

func TestConvertShareLinksToXrayJson_VmessPlainURL(t *testing.T) {
	link := "vmess://" + testShareUUID + "@vm.example:443?encryption=auto&type=tcp&headerType=http&path=%2Fpath1%2C%2Fpath2&host=h1%2Ch2"
	cfg, err := convertShareLinksForTest(link)
	require.NoError(t, err)
	var s conf.VMessOutboundConfig
	require.NoError(t, json.Unmarshal(*cfg.OutboundConfigs[0].Settings, &s))
	assert.Equal(t, testShareUUID, s.ID)
	assert.Equal(t, "auto", s.Security)
	ss := cfg.OutboundConfigs[0].StreamSetting
	require.NotNil(t, ss)
	require.NotNil(t, ss.RAWSettings)
}

func TestConvertShareLinksToXrayJson_VmessAEADWebSocketTLS(t *testing.T) {
	link := "vmess://" + testShareUUID + "@vm.example:8443?encryption=auto&type=ws&host=ws.host&path=%2Fw&security=tls&sni=tls.sni&alpn=h2%2Ch3&fp=safari#VMessAEAD"
	cfg, err := convertShareLinksForTest(link)
	require.NoError(t, err)
	assert.Equal(t, "VMessAEAD", cfg.OutboundConfigs[0].Tag)
	assert.Nil(t, cfg.OutboundConfigs[0].SendThrough)
	var s conf.VMessOutboundConfig
	require.NoError(t, json.Unmarshal(*cfg.OutboundConfigs[0].Settings, &s))
	assert.Equal(t, testShareUUID, s.ID)
	ss := cfg.OutboundConfigs[0].StreamSetting
	require.NotNil(t, ss)
	require.NotNil(t, ss.WSSettings)
	assert.Equal(t, "/w", ss.WSSettings.Path)
	assert.Equal(t, "tls", ss.Security)
	require.NotNil(t, ss.TLSSettings)
	assert.Equal(t, "tls.sni", ss.TLSSettings.ServerName)
}

func TestConvertShareLinksToXrayJson_TransportKcpGrpcHttpUpgradeXhttp(t *testing.T) {
	t.Run("kcp", func(t *testing.T) {
		link := "vless://" + testShareUUID + "@k.example:443?encryption=none&type=kcp&headerType=srtp&seed=myseed"
		cfg, err := convertShareLinksForTest(link)
		require.NoError(t, err)
		assert.Nil(t, cfg.OutboundConfigs[0].StreamSetting.KCPSettings)
	})

	t.Run("grpc", func(t *testing.T) {
		link := "vless://" + testShareUUID + "@g.example:443?encryption=none&type=grpc&serviceName=svc&authority=auth.here&mode=multi"
		cfg, err := convertShareLinksForTest(link)
		require.NoError(t, err)
		gs := cfg.OutboundConfigs[0].StreamSetting.GRPCSettings
		require.NotNil(t, gs)
		assert.Equal(t, "svc", gs.ServiceName)
		assert.Equal(t, "auth.here", gs.Authority)
		assert.True(t, gs.MultiMode)
	})

	t.Run("httpupgrade", func(t *testing.T) {
		link := "vless://" + testShareUUID + "@hu.example:443?encryption=none&type=httpupgrade&path=%2Fup&host=hu.host"
		cfg, err := convertShareLinksForTest(link)
		require.NoError(t, err)
		h := cfg.OutboundConfigs[0].StreamSetting.HTTPUPGRADESettings
		require.NotNil(t, h)
		assert.Equal(t, "/up", h.Path)
		assert.Equal(t, "hu.host", h.Host)
	})

	t.Run("xhttp_extra", func(t *testing.T) {
		extra := `{"host":"xh.extra"}`
		link := "vless://" + testShareUUID + "@xh.example:443?encryption=none&type=xhttp&path=%2Fx&host=xh.host&mode=stream-up&extra=" +
			url.QueryEscape(extra)
		cfg, err := convertShareLinksForTest(link)
		require.NoError(t, err)
		x := cfg.OutboundConfigs[0].StreamSetting.XHTTPSettings
		require.NotNil(t, x)
		assert.Nil(t, cfg.OutboundConfigs[0].StreamSetting.SplitHTTPSettings)
		assert.Equal(t, "stream-up", x.Mode)
		require.NotNil(t, x.Extra)
	})
}

func TestConvertShareLinksToXrayJson_FinalMaskQuery(t *testing.T) {
	fm := `{"udp":[{"type":"noise","settings":{}}]}`
	link := "vless://" + testShareUUID + "@fm.example:443?encryption=none&type=tcp&fm=" + url.QueryEscape(fm)
	cfg, err := convertShareLinksForTest(link)
	require.NoError(t, err)
	ss := cfg.OutboundConfigs[0].StreamSetting
	require.NotNil(t, ss.FinalMask)
	require.Len(t, ss.FinalMask.Udp, 1)
	assert.Equal(t, "noise", ss.FinalMask.Udp[0].Type)
}

func TestConvertShareLinksToXrayJson_MultiLineSkipsBad(t *testing.T) {
	bad := "vmess://" + testShareUUID + "@bad.example:notaport?encryption=none"
	good := "vless://" + testShareUUID + "@ok.example:443?encryption=none"
	cfg, err := convertShareLinksForTest(bad + "\n\n" + good)
	require.NoError(t, err)
	require.Len(t, cfg.OutboundConfigs, 1)
	assert.Equal(t, "vless", cfg.OutboundConfigs[0].Protocol)
}

func TestConvertShareLinksToXrayJson_TextHeaderBeforeShareLines(t *testing.T) {
	good := "vless://" + testShareUUID + "@ok.example:443?encryption=none"
	text := "Subscription export\n" +
		"# generated by a client\n" +
		"\n" +
		"updated: today\n" +
		"nodes:\n" +
		"---\n" +
		good

	cfg, err := convertShareLinksForTest(text)
	require.NoError(t, err)
	require.Len(t, cfg.OutboundConfigs, 1)
	assert.Equal(t, "vless", cfg.OutboundConfigs[0].Protocol)
}

func TestConvertShareLinksToXrayJson_DetectedShareLinesAllInvalid(t *testing.T) {
	bad := "vmess://" + testShareUUID + "@bad.example:notaport?encryption=none"
	_, err := convertShareLinksForTest("Subscription export\n" + bad)
	require.Error(t, err)
	assert.Contains(t, err.Error(), "no valid outbound found")
}

func TestConvertShareLinksToXrayJson_Base64EncodedJSON(t *testing.T) {
	orig, err := convertShareLinksForTest(
		"vless://" + testShareUUID + "@json.example:443?encryption=none",
	)
	require.NoError(t, err)
	raw, err := json.Marshal(orig)
	require.NoError(t, err)

	cfg, err := convertShareLinksForTest(base64.StdEncoding.EncodeToString(raw))
	require.NoError(t, err)
	require.Len(t, cfg.OutboundConfigs, 1)
	assert.Equal(t, "vless", cfg.OutboundConfigs[0].Protocol)
}

func TestConvertShareLinksToXrayJson_UnsupportedFormat(t *testing.T) {
	_, err := convertShareLinksForTest("this is not a supported subscription format")
	require.Error(t, err)
	assert.Contains(t, err.Error(), "unsupported share format")
}

func TestConvertShareLinksToXrayJson_VmessAEADGrpcAndKcp(t *testing.T) {
	t.Run("grpc", func(t *testing.T) {
		link := "vmess://" + testShareUUID + "@grpc.host:443?type=grpc&serviceName=svcname&mode=multi#g"
		cfg, err := convertShareLinksForTest(link)
		require.NoError(t, err)
		gs := cfg.OutboundConfigs[0].StreamSetting.GRPCSettings
		require.NotNil(t, gs)
		assert.Equal(t, "svcname", gs.ServiceName)
		assert.True(t, gs.MultiMode)
	})

	t.Run("kcp", func(t *testing.T) {
		link := "vmess://" + testShareUUID + "@kcp.host:8391?type=kcp#k"
		cfg, err := convertShareLinksForTest(link)
		require.NoError(t, err)
		assert.Nil(t, cfg.OutboundConfigs[0].StreamSetting.KCPSettings)
	})
}

func TestConvertShareLinksToXrayJson_ShadowsocksWithStreamQuery(t *testing.T) {
	link := "ss://" + ssUserB64("aes-128-gcm", "p") + "@ss-ws.example:443?type=ws&path=%2Fws&host=cdn.ws&security=tls&sni=ss-ws.example"
	cfg, err := convertShareLinksForTest(link)
	require.NoError(t, err)
	ss := cfg.OutboundConfigs[0].StreamSetting
	require.NotNil(t, ss.WSSettings)
	assert.Equal(t, "tls", ss.Security)
}
